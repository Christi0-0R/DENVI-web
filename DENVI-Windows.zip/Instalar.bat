@echo off
title Instalar DENVI

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-denvi.ps1"

pause