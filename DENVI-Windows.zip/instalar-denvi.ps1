
# =========================================
# INSTALADOR DE DENVI PARA WINDOWS
# =========================================

$ErrorActionPreference = "Stop"

$Origen = Join-Path $PSScriptRoot "dist\denvi"
$Destino = Join-Path $env:LOCALAPPDATA "Programs\DENVI"

Write-Host "================================="
Write-Host "       INSTALADOR DENVI"
Write-Host "================================="

try {
    # Comprobar que exista el ejecutable
    if (!(Test-Path (Join-Path $Origen "denvi.exe"))) {
        throw "No se encontro dist\denvi\denvi.exe"
    }

    # Copiar DENVI y el runtime de Java
    New-Item -ItemType Directory -Force -Path $Destino | Out-Null
    Copy-Item "$Origen\*" $Destino -Recurse -Force

    # Obtener PATH del usuario
    $PathActual = [Environment]::GetEnvironmentVariable("Path", "User")

    $Rutas = @(
        $PathActual -split ";" |
        Where-Object { $_ -and $_.Trim() }
    )

    # Evitar duplicados
    $Existe = $Rutas | Where-Object {
        $_.TrimEnd("\") -ieq $Destino.TrimEnd("\")
    }

    if (!$Existe) {
        $Rutas += $Destino
    }

    # Guardar PATH permanentemente
    [Environment]::SetEnvironmentVariable(
        "Path",
        ($Rutas -join ";"),
        "User"
    )

    # Notificar a Windows que cambio el PATH
    if (-not ("DenviEnvironmentNotifier" -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class DenviEnvironmentNotifier {
    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
    public static extern IntPtr SendMessageTimeout(
        IntPtr hWnd,
        uint Msg,
        UIntPtr wParam,
        string lParam,
        uint fuFlags,
        uint uTimeout,
        out UIntPtr lpdwResult
    );
}
"@
    }

    $resultado = [UIntPtr]::Zero

    [DenviEnvironmentNotifier]::SendMessageTimeout(
        [IntPtr]::Zero,
        0x001A,
        [UIntPtr]::Zero,
        "Environment",
        0x0002,
        5000,
        [ref]$resultado
    ) | Out-Null

    Write-Host ""
    Write-Host "DENVI SE INSTALO CORRECTAMENTE" -ForegroundColor Green
    Write-Host "Ubicacion: $Destino"
    Write-Host ""
    Write-Host "Cierra y vuelve a abrir PowerShell."
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

