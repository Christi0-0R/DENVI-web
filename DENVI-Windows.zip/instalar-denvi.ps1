# =========================================
# INSTALADOR DE DENVI PARA WINDOWS
# =========================================

$ErrorActionPreference = "Stop"

$Origen      = Join-Path $PSScriptRoot "dist\denvi"
$BinOrigen   = Join-Path $PSScriptRoot "bin"
$Destino     = Join-Path $env:LOCALAPPDATA "Programs\DENVI"
$DestinoBin  = Join-Path $Destino "bin"

Write-Host "================================="
Write-Host "       INSTALADOR DENVI"
Write-Host "================================="

try {
    # Comprobar que existan los archivos necesarios
    if (!(Test-Path (Join-Path $Origen "denvi.exe"))) {
        throw "No se encontro dist\denvi\denvi.exe"
    }
    if (!(Test-Path (Join-Path $BinOrigen "denvi.cmd"))) {
        throw "No se encontro bin\denvi.cmd"
    }

    # Si DENVI esta en ejecucion, detenerlo para poder reemplazar archivos
    Get-Process -Name "denvi" -ErrorAction SilentlyContinue | Stop-Process -Force

    # Copiar DENVI y el runtime de Java
    New-Item -ItemType Directory -Force -Path $Destino | Out-Null
    Copy-Item "$Origen\*" $Destino -Recurse -Force

    # Copiar el lanzador (comando "denvi")
    New-Item -ItemType Directory -Force -Path $DestinoBin | Out-Null
    Copy-Item "$BinOrigen\*" $DestinoBin -Recurse -Force

    # Obtener PATH del usuario
    $PathActual = [Environment]::GetEnvironmentVariable("Path", "User")

    # Quitar la ruta antigua (la carpeta con denvi.exe) para que no tape al lanzador
    $Rutas = @(
        $PathActual -split ";" |
        Where-Object {
            $_ -and $_.Trim() -and
            $_.TrimEnd("\") -ine $Destino.TrimEnd("\")
        }
    )

    # Evitar duplicados
    $Existe = $Rutas | Where-Object {
        $_.TrimEnd("\") -ieq $DestinoBin.TrimEnd("\")
    }

    if (!$Existe) {
        $Rutas += $DestinoBin
    }

    # Guardar PATH permanentemente
    [Environment]::SetEnvironmentVariable(
        "Path",
        ($Rutas -join ";"),
        "User"
    )

    # Notificar a Windows que cambio el PATH
    if (-not ("DenviEnvironmentNotifier" -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class DenviEnvironmentNotifier {
    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
    public static extern IntPtr SendMessageTimeout(
        IntPtr hWnd,
        uint Msg,
        UIntPtr wParam,
        string lParam,
        uint fuFlags,
        uint uTimeout,
        out UIntPtr lpdwResult
    );
}
"@
    }

    $resultado = [UIntPtr]::Zero

    [DenviEnvironmentNotifier]::SendMessageTimeout(
        [IntPtr]::Zero,
        0x001A,
        [UIntPtr]::Zero,
        "Environment",
        0x0002,
        5000,
        [ref]$resultado
    ) | Out-Null

    Write-Host ""
    Write-Host "DENVI SE INSTALO CORRECTAMENTE" -ForegroundColor Green
    Write-Host "Ubicacion: $Destino"
    Write-Host ""
    Write-Host "Cierra y vuelve a abrir PowerShell."
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}