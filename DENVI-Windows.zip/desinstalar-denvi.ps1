
# =========================================
# DESINSTALADOR DE DENVI PARA WINDOWS
# =========================================

$Destino = Join-Path $env:LOCALAPPDATA "Programs\DENVI"

Write-Host "================================="
Write-Host "      DESINSTALADOR DENVI"
Write-Host "================================="

try {
    # Obtener PATH del usuario
    $PathActual = [Environment]::GetEnvironmentVariable("Path", "User")

    # Eliminar solamente la ruta de DENVI
    $Rutas = @(
        $PathActual -split ";" |
        Where-Object {
            $_ -and
            $_.TrimEnd("\") -ine $Destino.TrimEnd("\")
        }
    )

    # Guardar PATH actualizado
    $NuevoPath = $Rutas -join ";"
    [Environment]::SetEnvironmentVariable("Path", $NuevoPath, "User")

    # Actualizar terminal actual
    $env:Path = (
        $env:Path -split ";" |
        Where-Object {
            $_ -and
            $_.TrimEnd("\") -ine $Destino.TrimEnd("\")
        }
    ) -join ";"

    # Eliminar archivos instalados
    if (Test-Path $Destino) {
        Remove-Item $Destino -Recurse -Force
    }

    Write-Host ""
    Write-Host "DENVI SE DESINSTALO CORRECTAMENTE" -ForegroundColor Green
    Write-Host "Se eliminaron sus archivos y su ruta del PATH."
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

