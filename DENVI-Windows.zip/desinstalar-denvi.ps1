# =========================================
# DESINSTALADOR DE DENVI PARA WINDOWS
# =========================================

$Destino    = Join-Path $env:LOCALAPPDATA "Programs\DENVI"
$DestinoBin = Join-Path $Destino "bin"
$Registros  = Join-Path $env:LOCALAPPDATA "DENVI"

Write-Host "================================="
Write-Host "      DESINSTALADOR DENVI"
Write-Host "================================="

try {
    # Detener DENVI si esta en ejecucion (si no, no se pueden borrar sus archivos)
    Get-Process -Name "denvi" -ErrorAction SilentlyContinue | Stop-Process -Force

    $Quitar = @($Destino.TrimEnd("\"), $DestinoBin.TrimEnd("\"))

    # Obtener PATH del usuario
    $PathActual = [Environment]::GetEnvironmentVariable("Path", "User")

    # Eliminar solamente las rutas de DENVI
    $Rutas = @(
        $PathActual -split ";" |
        Where-Object { $_ -and ($Quitar -notcontains $_.TrimEnd("\")) }
    )

    # Guardar PATH actualizado
    [Environment]::SetEnvironmentVariable("Path", ($Rutas -join ";"), "User")

    # Actualizar terminal actual
    $env:Path = (
        $env:Path -split ";" |
        Where-Object { $_ -and ($Quitar -notcontains $_.TrimEnd("\")) }
    ) -join ";"

    # Eliminar archivos instalados y registros
    if (Test-Path $Destino)   { Remove-Item $Destino -Recurse -Force }
    if (Test-Path $Registros) { Remove-Item $Registros -Recurse -Force }

    Write-Host ""
    Write-Host "DENVI SE DESINSTALO CORRECTAMENTE" -ForegroundColor Green
    Write-Host "Se eliminaron sus archivos y su ruta del PATH."
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""