@echo off
title Desinstalar DENVI

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0desinstalar-denvi.ps1"

pause